# Conexión con la base de datos

import sys
import mysql.connector as db


class Base_Datos():
    def __init__(self):
        self.conexion = mysql.connector.connect(host='localhost',
                                                database='educationservices1',
                                                user='root',
                                                password='admin')
#cupos docente docente_asigna_clases estudiante estudiante_inscribe_clasers

    def Insertar_Asignaturas(self,Asignaturas,Fecha_Inicio_Clase,Fecha_Fin_Clase,Hora_Inicio_Clase,Hora_Fin_Clase,Dias_Clase,Número_Clases):
        cur=self.conexion.cursor()
        sql='''INSERT INTO cupos (Asignaturas,Fecha_Inicio_Clase,Fecha_Fin_Clase,Hora_Inicio_Clase,Hora_Fin_Clase,Dias_Clase,Número_Clases)
        VALUES('{}','{}','{}','{}','{}','{}','{}')'''.format(Asignaturas,Fecha_Inicio_Clase,Fecha_Fin_Clase,Hora_Inicio_Clase,Hora_Fin_Clase,Dias_Clase,Número_Clases)
        cur=execute(sql)
        self.conexion.commit()
        cur.close

    def Insertar_Docente(self,ID_Docente,Nombre_Docente,Apellido_Docente,Usuario_Docente,Contraseña_Docente,Celular_Docente,Correo_Docente,FN_Docente,Sexo_Docente):
        cur=self.conexion.cursor()
        sql='''INSERT INTO docente (ID_Docente,Nombre_Docente,Apellido_Docente,Usuario_Docente,Contraseña_Docente,Celular_Docente,Correo_Docente,FN_Docente,Sexo_Docente)
        VALUES('{}','{}','{}','{}','{}','{}','{}')'''.format(ID_Docente,Nombre_Docente,Apellido_Docente,Usuario_Docente,Contraseña_Docente,Celular_Docente,Correo_Docente,FN_Docente,Sexo_Docente)
        cur=execute(sql)
        self.conexion.commit()
        cur.close

    def Insertar_Docente(self,ID_Docente,Nombre_Docente,Apellido_Docente,Usuario_Docente,Contraseña_Docente,Celular_Docente,Correo_Docente,FN_Docente,Sexo_Docente):
        cur=self.conexion.cursor()
        sql='''INSERT INTO docente (ID_Docente,Nombre_Docente,Apellido_Docente,Usuario_Docente,Contraseña_Docente,Celular_Docente,Correo_Docente,FN_Docente,Sexo_Docente)
        VALUES('{}','{}','{}','{}','{}','{}','{}')'''.format(ID_Docente,Nombre_Docente,Apellido_Docente,Usuario_Docente,Contraseña_Docente,Celular_Docente,Correo_Docente,FN_Docente,Sexo_Docente)
        cur=execute(sql)
        self.conexion.commit()
        cur.close

    def Insertar_Estudiante(self,ID_Estudiante,Nombre_Estudiante,Apellidos_Estudiante,Usuario_Estudiante,Contraseña_Estudiante,Celular_Estudiante,Correo_Estudiante,FN_Estudiante,Sexo_Estudiante):
        cur=self.conexion.cursor()
        sql='''INSERT INTO estudiante (ID_Estudiante,Nombre_Estudiante,Apellidos_Estudiante,Usuario_Estudiante,Contraseña_Estudiante,Celular_Estudiante,Correo_Estudiante,FN_Estudiante,Sexo_Estudiante)
        VALUES('{}','{}','{}','{}','{}','{}','{}')'''.format(ID_Estudiante,Nombre_Estudiante,Apellidos_Estudiante,Usuario_Estudiante,Contraseña_Estudiante,Celular_Estudiante,Correo_Estudiante,FN_Estudiante,Sexo_Estudiante)
        cur=execute(sql)
        self.conexion.commit()
        cur.close