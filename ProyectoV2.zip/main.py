import sys
from PyQt5.QtWidgets import QApplication,QMainWindow,QHeaderView
from PyQt5.QtCore import QPropertyAnimation,QEasingCurve
from PyQt5 import QtWidgets
from PyQt5 import QtCore
from PyQt5.uic import loadUi
from conexion_sqlite import Comunicacion

class VentanaPrincipal(QMainWindow):
    def __init__(self):
        super(VentanaPrincipal, self).__init__()
        loadUi('C:\Escritorio\DAVID\VS_Code\Proyecto\Proyecto\mante.ui',self)
        self.provf=0
        

        self.bt_menu.clicked.connect(self.mover_menu)

        self.base_datos = Comunicacion()

        self.bt_minimizar.clicked.connect(self.control_bt_minimizar)
        self.bt_colapsar.clicked.connect(self.control_bt_normal)
        self.bt_cerrar.clicked.connect(lambda: self.close())
    
        #self.bt_database.clicked.connect(self.basededatos_mantenimiento)
        self.bt_registrar.clicked.connect(self.registrar_mantenimiento)
        # self.bt_actualizar.clicked.connect(self.modificar_mantenimiento)
        # self.bt_eliminar.clicked.connect(self.eliminar_mantenimiento)
        # self.bt_program.clicked.connect(self.programacion_mantenimiento)
        # self.bt_pgElim_consul.clicked.connect(self.buscar_OT_eliminar)
        # self.bt_pgElim_save.clicked.connect(self.actualiza_OT_eliminar)
        # self.bt_pgAct_consul.clicked.connect(self.buscar_OT_modificar)
        # self.bt_pgAct_save.clicked.connect(self.actualizar_OT_modificar)
        self.bt_pgReg_save.clicked.connect(self.registrar_mantenimiento)
        # self.bt_pgBD_refrescar.clicked.connect(self.actualizar_OT)
        #Eliminar barra de titulo y opacidad
        self.setWindowFlag(QtCore.Qt.FramelessWindowHint)
        self.setWindowOpacity(1)


        #Mover ventana
        self.frame_superior.mouseMoveEvent = self.mover_ventana

        #Conección de botones
        self.bt_database.clicked.connect(lambda: self.stackedWidget.setCurrentWidget(self.page_base_datos))
        self.bt_registrar.clicked.connect(lambda: self.stackedWidget.setCurrentWidget(self.page_registrar))
        self.bt_actualizar.clicked.connect(lambda: self.stackedWidget.setCurrentWidget(self.page_actualizar))
        self.bt_eliminar.clicked.connect(lambda: self.stackedWidget.setCurrentWidget(self.page_eliminar))
        self.bt_program.clicked.connect(lambda: self.stackedWidget.setCurrentWidget(self.page_program))

        # Ancho de columna adaptable
        self.tabla_OT_pgElim.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.tabla_OT_pgBD.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)

        
        #SizeGrip
        self.gripSize=10
        self.grip=QtWidgets.QSizeGrip(self)
        self.grip.resize(self.gripSize,self.gripSize)

    def control_bt_minimizar(self):
        self.showMinimized()

    def control_bt_normal(self):
        if self.provf ==0:
            self.showNormal()
            self.provf=1
        else:
            self.showMaximized()
            self.provf=0
    def control_bt_maximizar(self):
        self.showMaximized()
    ### SizeGrip
    def resizeEvent(self,event):
        rect=self.rect()
        self.grip.move(rect.right()-self.gripSize,rect.bottom()-self.gripSize)
    ###Mover ventana
    def mousePressEvent(self,event):
        self.click_position = event.globalPos()
    def mover_ventana(self,event):
        if self.isMaximized()==False:
            if event.buttons()==QtCore.Qt.LeftButton:
                self.move(self.pos()+event.globalPos()-self.click_position)
                self.click_position=event.globalPos()
                event.accept()
        if event.globalPOs().y()<=10:
            self.showMaximized()
        else:
            self.showNormal()
    def mover_menu(self):
        if True:
            width=self.frame_menu.width()
            normal=0
            if width==0:
                extender=300
            else:
                extender=normal
            self.animacion=QPropertyAnimation(self.frame_menu,b'minimumWidth')
            self.animacion.setDuration(300)
            self.animacion.setStartValue(width)
            self.animacion.setEndValue(extender)
            self.animacion.setEasingCurve(QtCore.QEasingCurve.InOutQuart)
            self.animacion.start()

    def registrar_mantenimiento(self):
        codigo =self.txb_pgReg_cod.text().upper()
        nombre =self.txb_pgReg_fech.text().upper()
        modelo =self.txb_pgReg_km.text().upper()
        precio =self.txb_pgReg_rep.text().upper()
        cantidad =self.txb_pgReg_trab.text().upper()
        if codigo!='' and nombre!='' and modelo!='' and cantidad!='' and precio!='':
            self.base_datos.registrar_mantenimiento(codigo,nombre,modelo,precio,cantidad)
            self.signal_registrar.setText('Productos Registrados')
            codigo =self.txb_pgReg_cod.clear()
            nombre =self.txb_pgReg_fech.clear()
            modelo =self.txb_pgReg_km.clear()
            precio =self.txb_pgReg_rep.tclear()
            cantidad =self.txb_pgReg_trab.clear()
        else:
            self.label_8.setText('Hay Espacios Vacios')

if __name__ == "__main__":
    app = QApplication(sys.argv)
    mi_app = VentanaPrincipal()
    mi_app.show()
    sys.exit(app.exec_())